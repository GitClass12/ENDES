package scr.endes.baremo;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class BaremoTests {

	@Test
	void test1() {
		assertEquals("No adjudicada", Baremo.comprobarBaremo("1234567A", 4));
	}

	@Test
	void test2() {
		assertEquals("Adjudicada", Baremo.comprobarBaremo("1234567A", 9));
	}

	@Test
	void test3() {
		assertEquals("Dato no Válido", Baremo.comprobarBaremo("123456A", 2));
	}

	@Test
	void test4() {
		assertEquals("Dato no Válido", Baremo.comprobarBaremo("1234567890A", 2));
	}

	@Test
	void test5() {
		assertEquals("Dato no Válido", Baremo.comprobarBaremo("1234ABC5", 2));
	}

	@Test
	void test6() {
		assertEquals("Dato no Válido", Baremo.comprobarBaremo("ABCD12345", 6));
	}

	@Test
	void test7() {
		assertEquals("Dato no Válido", Baremo.comprobarBaremo("1234567A", -5));
	}

	@Test
	void test8() {
		assertEquals("Dato no Válido", Baremo.comprobarBaremo("1234567A", 20));
	}

	@Test
	void test9() {
		// Da error incluso sin ejecutar
		// assertEquals("Dato no Válido", Baremo.comprobarBaremo("1234567A",
		// 7.5));
	}
}
