package scr.endes.cajablanca;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class CajaBlancaTest {

	@Test
	void ejercicio1() {
		// Camino 1: x = -5 ; y = ? ; salida = "x e y deben ser positivos"

		assertEquals(-1, CajaBlanca.ejercicio1(-5, 0));

		// Camino 2: x = 2 ; y = -5 ; salida = "x e y deben ser positivos"

		assertEquals(-1, CajaBlanca.ejercicio1(1, -1));

		// Camino 3: x = 4 ; y = 4 ; salida = "La media es: 4"

		assertEquals(4, CajaBlanca.ejercicio1(4, 4));
	}

	@Test
	void ejercicio2() {
		// Camino 1: a = 2 ; b = 6 ; c = 1 ; salida = 1

		assertEquals(1, CajaBlanca.ejercicio2(2, 6, 1));

		// Camino 2: a = 2 ; b = 6 ; c = 4 ; salida = -1

		assertEquals(-1, CajaBlanca.ejercicio2(2, 6, 4));

		// Camino 3: a = 2 ; b = 3 ; c = ? ; salida = -1

		assertEquals(-1, CajaBlanca.ejercicio2(2, 3, 1));

		// Camino 4: a = 0 ; b = ? ; c = ? ; salida = -1

		assertEquals(-1, CajaBlanca.ejercicio2(0, 6, 1));
	}

	@Test
	void ejercicio3() {
		// Camino 1: x = 3 ; y = 7 ; z = 4 ; salida = "El máximo es 7"

		assertEquals(7, CajaBlanca.ejercicio3(3, 7, 4));

		// Camino 2: x = 4 ; y = 3 ; z = 6 ; salida = "El máximo es 6"

		assertEquals(6, CajaBlanca.ejercicio3(4, 3, 6));

		// Camino 3: x = 1 ; y = 2 ; z = 3 ; salida = "El máximo es 3"

		assertEquals(3, CajaBlanca.ejercicio3(1, 2, 3));

		// Camino 4: x = 7 ; y = 6 ; z = 5 ; salida = "El máximo es 7"

		assertEquals(7, CajaBlanca.ejercicio3(7, 6, 5));

	}

	@Test
	void ejercicio4() {
		// Camino 1: cadena = "a", "b" ; lon = 2 ; letra = "a" ; salida = 1

		assertEquals(1, CajaBlanca.ejercicio4(new char[] { 'a', 'b' }, 'a'));

		// Camino 2: cadena = null ; lon = 0 ; letra = ? ; salida = 0

		assertEquals(0, CajaBlanca.ejercicio4(new char[] {}, 'a'));

		// Camino 3: cadena = "a" ; lon = 1 ; letra = "d" ; salida = 0

		assertEquals(0, CajaBlanca.ejercicio4(new char[] { 'a' }, 'd'));

		// Camino 4: cadena = "a" ; lon = 1 ; letra = "a" ; salida = 1

		assertEquals(1, CajaBlanca.ejercicio4(new char[] { 'a' }, 'a'));

	}
}
