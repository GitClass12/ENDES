package scr.endes.arrays;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

@TestMethodOrder(OrderAnnotation.class)
class ArraysTest {

	static int[] array1, array2, resul, array3, array4, resul2;

	@Test
	@Order(3)
	void testSumar() {
		MisArrays arra = new MisArrays();
		assertArrayEquals(resul, arra.sumar(array1, array2));
	}

	@Test
	@Order(2)
	void testSumar2() {
		MisArrays arra = new MisArrays();
		assertArrayEquals(resul2, arra.sumar(array3, array4));
	}

	@BeforeAll
	static void iniciar() {
		array1 = new int[] { 2, 4, 5 };
		array2 = new int[] { 1, 1, 1 };
		resul = new int[] { 3, 5, 6 };
		array3 = new int[] { 4, 7, 2, 4, 8 };
		array4 = new int[] { 12, 9, 6, 5, 2 };
		resul2 = new int[] { 16, 16, 8, 9, 10 };
	}

	@Test
	@Order(1)
	void testDecrementar() {
		MisArrays arra = new MisArrays();
		arra.decrementar(array1, 1);
		assertArrayEquals(array1, new int[] { 1, 3, 4 });
	}

	@BeforeEach
	void iniciar2() {
		array1 = new int[] { 2, 4, 5 };
		array2 = new int[] { 1, 1, 1 };
		resul = new int[] { 3, 5, 6 };
	}

	@AfterAll
	static void finalizar() {
		System.out.println("Fin de los tests");
	}
	
	@AfterEach
	void finalizar2() {
		System.out.println("Finaliza un test");
	}
}