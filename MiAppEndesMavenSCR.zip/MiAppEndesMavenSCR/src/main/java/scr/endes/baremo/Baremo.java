package scr.endes.baremo;

public class Baremo {

	 /* Este método comprueba si un dni es válido y luego a partir del baremo
	 comprueba si se adjudica o no */
	public static String comprobarBaremo(String DNI, int baremo) {
		if (DNI.matches("[0-9]{7}[A-Z]{1}")) {
			if (baremo >= 5 && baremo <= 10)
				return "Adjudicada";
			else if (baremo >= 0 && baremo <= 4)
				return "No adjudicada";
		}
		return "Dato no Válido";
	}
}
