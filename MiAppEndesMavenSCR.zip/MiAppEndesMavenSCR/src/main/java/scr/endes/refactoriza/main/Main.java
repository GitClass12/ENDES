package scr.endes.refactoriza.main;

import java.util.Map;
import java.util.Random;

import scr.endes.refactoriza.farmacia.Farmacia;
import scr.endes.refactoriza.medicamento.Medicamento;
import scr.endes.refactoriza.medicamento.MedicamentoEspecializado;

public class Main {
	private static final String DIABETES = "Diabetes";
	private static final String MEDICAMENTO10 = "Medicamento10";
	private static final String MEDICAMENTO9 = "Medicamento9";
	private static final String MEDICAMENTO8 = "Medicamento8";
	private static final String MEDICAMENTO7 = "Medicamento7";
	private static final String MEDICAMENTO6 = "Medicamento6";
	private static final String MEDICAMENTO5 = "Medicamento5";
	private static final String MEDICAMENTO4 = "Medicamento4";
	private static final String MEDICAMENTO2 = "Medicamento2";
	private static final String MEDICAMENTO1 = "Medicamento1";
	private static final String MEDICAMENTO3 = "Medicamento3";

	private static final double PRECIO1 = generarPrecio();
	private static final double PRECIO2 = generarPrecio();
	private static final double PRECIO3 = generarPrecio();
	private static final double PRECIO4 = generarPrecio();
	private static final double PRECIO5 = generarPrecio();
	private static final double PRECIO6 = generarPrecio();
	private static final double PRECIO7 = generarPrecio();
	private static final double PRECIO8 = generarPrecio();
	private static final double PRECIO9 = generarPrecio();
	private static final double PRECIO10 = generarPrecio();

	private static double generarPrecio() {
		Random random = new Random();
		return random.nextDouble() * 100;
	}

	public static void main(String[] args) {
		Farmacia farmacia = new Farmacia();

		// Añadir medicamentos generales
		Medicamento paracetamol = new Medicamento("Paracetamol", 10.0);
		farmacia.agregarMedicamento(paracetamol, 100);

		Medicamento medicamentoGenerico1 = new Medicamento(MEDICAMENTO1, PRECIO1);
		farmacia.agregarMedicamento(medicamentoGenerico1, 100);

		Medicamento medicamentoGenerico2 = new Medicamento(MEDICAMENTO2, PRECIO2);
		farmacia.agregarMedicamento(medicamentoGenerico2, 100);

		Medicamento medicamentoGenerico3 = new Medicamento(MEDICAMENTO3, PRECIO3);
		farmacia.agregarMedicamento(medicamentoGenerico3, 100);

		Medicamento medicamentoGenerico4 = new Medicamento(MEDICAMENTO4, PRECIO4);
		farmacia.agregarMedicamento(medicamentoGenerico4, 100);

		Medicamento medicamentoGenerico5 = new Medicamento(MEDICAMENTO5, PRECIO5);
		farmacia.agregarMedicamento(medicamentoGenerico5, 100);

		Medicamento medicamentoGenerico6 = new Medicamento(MEDICAMENTO6, PRECIO6);
		farmacia.agregarMedicamento(medicamentoGenerico6, 100);

		Medicamento medicamentoGenerico7 = new Medicamento(MEDICAMENTO7, PRECIO7);
		farmacia.agregarMedicamento(medicamentoGenerico7, 100);

		Medicamento medicamentoGenerico8 = new Medicamento(MEDICAMENTO8, PRECIO8);
		farmacia.agregarMedicamento(medicamentoGenerico8, 100);

		Medicamento medicamentoGenerico9 = new Medicamento(MEDICAMENTO9, PRECIO9);
		farmacia.agregarMedicamento(medicamentoGenerico9, 100);

		Medicamento medicamentoGenerico10 = new Medicamento(MEDICAMENTO10, PRECIO10);
		farmacia.agregarMedicamento(medicamentoGenerico10, 100);

		// Añadir medicamentos especializados
		MedicamentoEspecializado insulina = new MedicamentoEspecializado("Insulina", 50.0, DIABETES);
		farmacia.agregarMedicamento(insulina, 20);

		final String TIPO1 = "Tipo1";
		MedicamentoEspecializado medicamentoEspecializado1 = new MedicamentoEspecializado(MEDICAMENTO1, PRECIO1, TIPO1);
		farmacia.agregarMedicamento(medicamentoEspecializado1, 20);

		final String TIPO2 = "Tipo2";
		MedicamentoEspecializado medicamentoEspecializado2 = new MedicamentoEspecializado(MEDICAMENTO2, PRECIO2, TIPO2);
		farmacia.agregarMedicamento(medicamentoEspecializado2, 20);

		final String TIPO3 = "Tipo3";
		MedicamentoEspecializado medicamentoEspecializado3 = new MedicamentoEspecializado(MEDICAMENTO3, PRECIO3, TIPO3);
		farmacia.agregarMedicamento(medicamentoEspecializado3, 20);

		final String TIPO4 = "Tipo4";
		MedicamentoEspecializado medicamentoEspecializado4 = new MedicamentoEspecializado(MEDICAMENTO4, PRECIO4, TIPO4);
		farmacia.agregarMedicamento(medicamentoEspecializado4, 20);

		final String TIPO5 = "Tipo5";
		MedicamentoEspecializado medicamentoEspecializado5 = new MedicamentoEspecializado(MEDICAMENTO5, PRECIO5, TIPO5);
		farmacia.agregarMedicamento(medicamentoEspecializado5, 20);

		final String TIPO6 = "Tipo6";
		MedicamentoEspecializado medicamentoEspecializado6 = new MedicamentoEspecializado(MEDICAMENTO6, PRECIO6, TIPO6);
		farmacia.agregarMedicamento(medicamentoEspecializado6, 20);

		final String TIPO7 = "Tipo7";
		MedicamentoEspecializado medicamentoEspecializado7 = new MedicamentoEspecializado(MEDICAMENTO7, PRECIO7, TIPO7);
		farmacia.agregarMedicamento(medicamentoEspecializado7, 20);

		final String TIPO8 = "Tipo8";
		MedicamentoEspecializado medicamentoEspecializado8 = new MedicamentoEspecializado(MEDICAMENTO8, PRECIO8, TIPO8);
		farmacia.agregarMedicamento(medicamentoEspecializado8, 20);

		final String TIPO9 = "Tipo9";
		MedicamentoEspecializado medicamentoEspecializado9 = new MedicamentoEspecializado(MEDICAMENTO9, PRECIO9, TIPO9);
		farmacia.agregarMedicamento(medicamentoEspecializado9, 20);

		final String TIPO10 = "Tipo10";
		MedicamentoEspecializado medicamentoEspecializado10 = new MedicamentoEspecializado(MEDICAMENTO10, PRECIO10,
				TIPO10);
		farmacia.agregarMedicamento(medicamentoEspecializado10, 20);

		System.out.println("Inventario de la farmacia:");
		for (Map.Entry<String, Integer> entry : farmacia.getInventario().entrySet()) {
			System.out.println(entry.getKey() + ": " + entry.getValue() + " unidades");
		}
	}
}
