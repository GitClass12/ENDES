package scr.endes.refactoriza.medicamento;

public class Medicamento {
	public String nombre;
	public double precio;

	public Medicamento(String nombre, double precio) {
		this.nombre = nombre;
		this.precio = precio;
	}
}
