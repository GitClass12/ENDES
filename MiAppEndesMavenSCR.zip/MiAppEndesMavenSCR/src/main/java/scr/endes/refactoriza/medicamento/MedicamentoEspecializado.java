package scr.endes.refactoriza.medicamento;

public class MedicamentoEspecializado extends Medicamento {
	private String tipo;

	public MedicamentoEspecializado(String nombre, double precio, String tipo) {
		super(nombre, precio);
		this.tipo = tipo;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public String mostrarMedicamento() {
		return "Nombre: " + nombre + ", Precio: " + precio + ", Tipo: " + tipo;
	}
}