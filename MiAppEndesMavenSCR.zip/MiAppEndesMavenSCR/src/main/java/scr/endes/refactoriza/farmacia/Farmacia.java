package scr.endes.refactoriza.farmacia;

import java.util.HashMap;
import java.util.Map;
import scr.endes.refactoriza.medicamento.Medicamento;

public class Farmacia {
	private Map<String, Integer> inventario;

	public Farmacia() {
		this.setInventario(new HashMap<>());
	}

	// Metodo para agregar medicamento //
	public void agregarMedicamento(Medicamento medicamento, int cantidad) {
		String nombre = medicamento.nombre;
		if (getInventario().containsKey(nombre)) {
			int cantidadExistente = getInventario().get(nombre);
			getInventario().put(nombre, cantidadExistente + cantidad);
		} else {
			getInventario().put(nombre, cantidad);
		}
	}

	public Map<String, Integer> getInventario() {
		return inventario;
	}

	public void setInventario(Map<String, Integer> inventario) {
		this.inventario = inventario;
	}
}