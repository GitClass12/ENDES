package scr.endes.cajablanca;

public class CajaBlanca {

	// Devuelve la media de los números dados
	public static float ejercicio1(int x, int y) {
		float resultado = -1;
		if (x < 0 || y < 0) {
			System.out.println("x e y deben ser positivos");
		} else {
			resultado = (x + y) / 2.0f;
			System.out.print("La media es: " + resultado);
		}
		return resultado;
	}

	// Si se cumplen las condiciones devuelve 1, si no -1
	public static int ejercicio2(int a, int b, int c) {
		int x = 0;
		if (a > 1 && (b > 5) && (c < 2)) {
			x = x + 1;
		} else
			x = x - 1;
		return x;
	}

	// Devuelve el número con más valor
	public static int ejercicio3(int x, int y, int z) {
		int max = 0;
		if (x > y && x > z)
			max = x;
		else if (z > y)
			max = z;
		else
			max = y;
		return max;
	}

	/* Devuelve el número de letras de la cadena que son iguales
	a la letra pasada */
	public static int ejercicio4(char[] cadena, char letra) {
		int contador, n, lon;
		n = 0;
		contador = 0;
		lon = cadena.length;
		if (lon > 0) {
			do {
				if (cadena[contador] == letra)
					n++;
				contador++;
				lon--;
			} while (lon > 0);
		}
		return n;
	}
}