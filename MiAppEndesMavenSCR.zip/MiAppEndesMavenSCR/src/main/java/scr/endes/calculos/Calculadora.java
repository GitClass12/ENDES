package scr.endes.calculos;

public class Calculadora {

	// Método para restar dos números
	public static int restar(int num1, int num2) {
		return num1 - num2;
	}

	// Método para dividir dos números
	public static int dividir(int num1, int num2) {
		return num1 / num2;
	}

	// Método para comprobar si un número es par
	public static boolean esPar(int num) {
		return (num % 2 == 0);
	}

	// Método que devuelve si el número es par o impar
	public static String esParOImpar(int num) {
		if (esPar(num)) {
			return "Par";
		} else {
			return "Impar";
		}
	}
}
